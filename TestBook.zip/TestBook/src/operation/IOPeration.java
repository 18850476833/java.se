package operation;

/**
 * Created with IntelliJ IDEA.
 * Description:
 * User: dong jin cheng
 * Date: 2023-10-14
 * Time: 20:18
 */

import book.BookList;


public interface IOPeration {
    void work(BookList bookList);
}
